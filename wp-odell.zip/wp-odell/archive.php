<?php get_header(); ?> 
        <section class="content">
          <div class="container">
          <?php if ( have_posts() ) : ?>
            <h1><?php single_cat_title( '', false ); ?></h1>
              <?php
                if ( category_description() ) : ?>
                <p><?php echo category_description(); ?></p>
                <?php endif; ?>
              <div class="content__posts">
                <?php
                  while ( have_posts() ) : the_post(); ?>
                <div class="post">
                <h4><?php the_title(); ?></h4>
                  <?php the_content(); ?>
                </div>
                <?php endwhile; 
                  else: ?>
                      <div class="post" style='text-align:center; height:40vh; margin-top: 30%'>
                        <h2>Sorry, no posts matched your criteria.</h2>
                      </div>
                <?php endif; ?>
            </div>
            <?php the_posts_pagination(); ?>
          </div>
        </section>
<?php get_footer(); ?>