<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0" />
    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php bloginfo('description'); ?>">

    <?php wp_head(); ?>
  </head>
  <body>
    <div class="wrapper">
      <header class="header">
        <div class="header__body">
          <div class="header__container">
            <input class="header__input" type="checkbox" />
            <div class="header__lines"></div>
            <div class="header__logo">
            <?php 
                    if( get_custom_logo() ) {
                        the_custom_logo();
                      } else {
                        ?><a href="/"><img src="<?php bloginfo('template_url'); ?>/assets/img/logo.png" alt="Odell" /></a><?php
                      }
                ?>
            </div>
            <div class="header__menus">
              <nav>
                <?php odell_header_top_menu() ?>
                <div class="telephone">
                  <a href="tel:<?php 
                      if(function_exists('get_field') && get_field('tel_number')){
                        $str = get_field('tel_number');
                      } else {
                        $str = '(469) 246-4500';
                      }
                        $pattern = '/[^0-9]/';
                        echo preg_replace($pattern, "", $str);
                      ?>"><?php odel_check_asf('tel_number', '(469) 246-4500') ?></a>
                </div>
              </nav>
              <nav>
                <?php odell_header_down_menu() ?>
              </nav>
            </div>
          </div>
        </div>
      </header>
      <main>







