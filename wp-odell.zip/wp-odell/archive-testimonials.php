<?php get_header(); ?> 
        <section class="content">
          <div class="container">
          <?php if ( have_posts() ) : ?>
            <h1>Testomonials:</h2>
              <div class="content__posts">

                <?php
                  while ( have_posts() ) : the_post(); ?>
                <!-- post 1 -->
                <div class="post  post__testimonials">
                <h4><?php the_title(); ?></h4>
                <div class="post__position"><?php odell_get_post_meta('position', $post); ?></div>
                <div class="post__address"><?php odell_get_post_meta('address', $post); ?></div>
                
                  <?php the_content(); ?>
              
                </div>
                <?php endwhile; 
                  else: ?>
                      <div class="post" style='text-align:center; height:40vh; margin-top: 30%'>
                        <h2>Sorry, no posts matched your criteria.</h2>
                      </div>
                <?php endif; ?>
            </div>
            <?php the_posts_pagination(); ?>


          </div>
        </section>

<?php get_footer(); ?>