<?php get_header(); ?>

        <section class="content">
          <div class="container">
            <div class="content__posts">
              <div class="post" style='text-align:center; height:40vh; margin-top: 30%'>
                <h2>404</h2>
                <div class="post__subtitle">Not Found!</div>
              </div>
            </div>
          </div>
        </section>

<?php get_footer(); ?>