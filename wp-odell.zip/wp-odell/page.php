<?php get_header();
      the_post(); ?>
        <section class="content">
          <div class="container">
            <h1><?php the_title(); ?></h1>
              <div>
                <div class="post">
                <?php
                      if(get_the_post_thumbnail_url()){
                        ?><img src="<?php the_post_thumbnail_url();?>"><?php
                      }
                      the_content();
                    ?>
                </div>
            </div>
          </div>
        </section>
<?php get_footer(); ?>