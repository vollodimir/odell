<?php
/*
Template Name: Home Template
*/
?>

<?php get_header(); ?>
        <section class="first-screen">
          <div class="first-screen__body">
            <div class="container">
              <div class="first-screen__text">
                <h2><?php odel_check_asf('first_screen_title', 'Odell Medical Search') ?></h2>
                <h1><?php odel_check_asf('first_screen_subtitle', 'Your Multi-Disciplined Healthcare Recruiting Resource') ?></h1>
              </div>
            </div>
          </div>
        </section>
        <section class="find-job">
          <div class="container">
            <div class="find-job__body">
              <div class="find-job__left">
                <h2><?php odel_check_asf('find_job_left_title', 'Find Your Next Job') ?></h2>
                <p><?php odel_check_asf('find_job_left_subtitle', 'Start searching for available positions.') ?></p>
                <form  role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                  <input
                    class="find-job__input-key"
                    type="text"
                    placeholder="Job Title, Skills or Keywords"
                    value="<?php echo get_search_query(); ?>" name="s" id="s"  
                  />
                  <input class="find-job__input-city" type="text" placeholder="City, Zip Code" />
                  <div class="btn btn__secondary"><button type="submit" id="searchsubmit" value="<?php echo esc_attr_x( 'Search', 'submit button' ); ?>">Search</button></div>
                </form>
                <div class="find-job__details">
                  <a href="<?php odel_check_asf('find_job_left_link_link', '#') ?>"><?php odel_check_asf('find_job_left_link_text', 'See why you should work with us to get hired') ?></a>
                </div>
              </div>

              <div class="find-job__right">
                <h2><?php odel_check_asf('find_job_right_title', 'Need Help Filling a Position?') ?></h2>
                <p><?php odel_check_asf('find_job_right_subtitle', 'Begin your search for top quality candidates') ?></p>
                <div class="btn btn__primary"><a href="<?php odel_check_asf('find_job_right_btn_link', '#') ?>">Submit A Job</a></div>
                <div class="find-job__details">
                  <a href="<?php odel_check_asf('find_job_right_link_link', '#') ?>"><?php odel_check_asf('find_job_right_link_text', 'Learn about our innovative approach to recruiting') ?></a>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="content">
          <div class="container">
            <div class="content__posts">
                <?php
                    $args = array(
                      'post_type'      => 'home_posts',
                      'posts_per_page' => 2,
                    );
                    $loop = new WP_Query($args);
                    while ( $loop->have_posts() ) {
                      $loop->the_post();
                  ?>
                  <div class="post">
                    <?php if( get_post_meta( $post->ID, $name, true ) || the_title() ) { ?>
                      <div class="post__subtitle"><?php odell_get_post_meta('subtitle', $post); ?></div>
                      <h2><?php the_title(); ?></h2>
                    <?php } ?>
                      <?php the_content(); ?>
                  </div>
                <?php
                  }
                ?>
                  <!-- end home_posts -->
                <!-- form -->
                <div class="post post__form">
                  <h3>Upload your Resume for a Confidential Job Search</h3>
                  <?php
                    if( function_exists('wpcf7')){
                      echo do_shortcode('[contact-form-7 id="27" title="Contact form"]');
                    } else {?>
                      <form>
                        <div class="post__input-group">
                          <input type="text" placeholder="First Name *" required />
                          <input type="text" placeholder="Last Name *" required />
                          <input type="email" placeholder="Email Address *" required />
                          <input type="tel" placeholder="Phone Number" />
                        </div>
                        <p>Upload your Resume *</p>
                        <div class="post__file">
                          <label>
                            <input type="file" accept=".docx, .pdf, .txt, .rtf" required />Сhoose File
                          </label>
                          <div class="post__file-title">
                            Accepted formats: doc, .docx, .pdf, .txt, .rtf, maximum size 8MB
                          </div>
                        </div>
                        <div class="post__btn">
                          <div class="btn btn__primary"><button type="submit">Submit</button></div>
                          <div class="post__btn-title">Fields with * are required</div>
                        </div>
                      </form>
                  <?php  } ?>



                </div>
                <!-- end form -->

                <!-- last testomonial -->
                <?php
                    $args = array(
                      'post_type'      => 'testimonials',
                      'posts_per_page' => 1,
                    );
                    $loop = new WP_Query($args);
                    while ( $loop->have_posts() ) {
                      $loop->the_post();
                  ?>
                  <div class="post  post__testimonials">
                      <h4><?php the_title(); ?></h4>
                      <div class="post__position"><?php odell_get_post_meta('position', $post); ?></div>
                      <div class="post__address"><?php odell_get_post_meta('address', $post); ?></div>
                      <?php the_content(); ?>
                    </div>
                  <?php
                    }
                  ?>
                <!-- end last testomonial -->
            </div>
          </div>
        </section>
  
<?php get_footer(); ?>