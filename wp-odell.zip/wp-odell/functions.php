<?php
	add_action( 'wp_enqueue_scripts', function () {
	 //styles 
		wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css' );
		wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css' );
	 //scripts
		wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), false, true );
	});


	// //post type

	// first page home posts
	function home_posts_create_post_type() {
		register_post_type( 'home_posts', array(
			'labels' => array(
				'menu_name' => 'Home posts',
				'singular_name' => 'Home post',
				'add_new' => 'Add home post'
			),
			'menu_position' => 6,
			//'show_in_rest' => true, //gutenberg
			'public' => true,
			'menu_icon' => 'dashicons-editor-table',
			'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'post-formats')
		) );
	}
	add_action( 'init', 'home_posts_create_post_type' );

	//testimonials
	function testimonials_create_post_type() {
		register_post_type( 'testimonials', array(
			'labels' => array(
				'menu_name' => 'Testimonials',
				'singular_name' => 'Testimonial',
				'add_new' => 'Add testimonial'
			),
			'menu_position' => 7,
			'has_archive' => true,
			'public' => true,
			'menu_icon' => 'dashicons-format-chat',
			'supports' => array('title', 'editor', 'custom-fields', 'post-formats'),
		) );
	}
	add_action( 'init', 'testimonials_create_post_type' );

	//enable standart custom fields
	add_filter('acf/settings/remove_wp_meta_box', '__return_false');


	//get post meta
	function odell_get_post_meta($name, $post){
		$price = get_post_meta( $post->ID, $name, true );
		if ( $price ) {
		echo $price;
		} 
	}

	//////cf7 delete p tag
	add_filter('wpcf7_autop_or_not', '__return_false');

	//////cf7 remove span
	add_filter('wpcf7_form_elements', function($content) {
		$content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);
		$content = str_replace('<br />', '', $content);
		return $content;
	});



	//// register my menus
	function odell_register_all_menus() {
		register_nav_menus(array(
			'header_top_menu' => 'Header top menu',
			'header_down_menu' => 'Header down menu',
			//'footer_menu' => 'Footer menu'
			)
		);
	}
	add_action( 'init', 'odell_register_all_menus' );
	
	//Theme Supports
	add_theme_support('menus');
	add_theme_support('post-thumbnails');
	add_theme_support('title-tag');
	add_theme_support('custom-logo');
	add_theme_support( 'html5', array( 'search-form' ) );
	


	
	///header top menu
	function odell_header_top_menu () {
		$args = array(
			'theme_location' => 'header_top_menu',
			'menu_class' => 'header__top-menu',
			'container'       => 'ul', 
			'echo' => 0 
		);
		$menu = wp_nav_menu( $args );
		echo $menu;
	}


	///header down menu (add first image to home page)
	function odell_header_down_menu () {
		$args = array(
			'theme_location' => 'header_down_menu',
			'menu_class' => 'header__down-menu',
			'container'       => 'ul', 
			'echo' => 0 
		  );
		$menu = wp_nav_menu( $args );
		$menu = preg_replace('~<li~', '<li><a href="/"><img src="'. get_template_directory_uri() .'/assets/img/icon/home.svg" alt="Home" /></a></li><li', $menu, 1 );
		echo $menu;
	}

	

	///check plugin activate 
	function odel_check_asf($fielf_asf, $echo_text) {
		if(function_exists('get_field') && get_field($fielf_asf)){
			the_field($fielf_asf); 
		 } else {
			echo $echo_text; 
		}

	}

	///old widgets ON
	//  add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
	//  add_filter( 'use_widgets_block_editor', '__return_false' );

	///add widgets area in footer
	function register_my_widgets(){
		register_sidebar(array(
			'name' => 'Address and pryvacy',
			'id' => 'address',
			'description' => 'First widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
		));
		register_sidebar(array(
			'name' => 'Footer Widget 1',
			'id' => 'footer-1',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
		));
		register_sidebar(array(
			'name' => 'Footer Widget 2',
			'id' => 'footer-2',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
		));
		register_sidebar(array(
			'name' => 'Footer Widget 3',
			'id' => 'footer-3',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
		));
		register_sidebar(array(
			'name' => 'Footer Widget 4',
			'id' => 'footer-4',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
			));
		register_sidebar(array(
			'name' => 'Footer Widget 5',
			'id' => 'footer-5',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__body">',
			'after_widget' => '</div>',
			'before_title' => '<h3>',
			'after_title' => '</h3>',
		));
		register_sidebar(array(
			'name' => 'Socials Widget',
			'id' => 'socials',
			'description' => 'Widget area in footer',
			'before_widget' => '<div class="widget__social">',
			'after_widget' => '</div>',
			'before_title' => '<h4>',
			'after_title' => '</h4>',
		));
	}
	add_action( 'widgets_init', 'register_my_widgets' );


?>


