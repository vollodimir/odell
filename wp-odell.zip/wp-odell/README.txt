WP Nursery Theme Guide

Steps:

	1. Install plugins (Plugins > Add New, search name plugins. Then install and activate.):
 
		- Advanced Custom Fields (https://wordpress.org/plugins/advanced-custom-fields/)
		- Contact Form 7 (https://wordpress.org/plugins/contact-form-7/)


	2. Download the demo data in site: Import > WordPress > select the demo_data.xml file. 
	   The demo data is located in the theme directory called demo_data.xml

	3. Enjoy!
	

Theme site: https://github.com/vollodimir/odell


==================================
*  HTML tags to footer widgets:  *
==================================



	1. Address and pryvacy:

<p>101 W Renner Rd, Suite 440, Richardson, TX 75082</p>
<p class="widget__privacy">
<a href="#">Privacy Policy</a> / <a href="#">Terms of Use</a>
</p>


	2. Footer Widget 1:

<ul>
    <li><a href="#">Employers</a></li>
    <li><a href="#">Job Seekers</a></li>
    <li><a href="#">Job Alerts</a></li>
</ul>


	3. Footer Widget 2:

<h3>Services</h3>
<ul>
    <li><a href="#">Contingency Search</a></li>
    <li><a href="#">Interim Leadership \ Contract</a></li>
    <li><a href="#">Locum Tenens</a></li>
    <li><a href="#">Retained Search</a></li>
</ul>


	4. Footer Widget 3:

<h3>Our Specialties</h3>
<ul>
<li><a href="#">Landing Pages (18)</a></li>
</ul>


	5. Footer Widget 4:

<ul>
    <li><a href="#">About Us</a></li>
    <li><a href="#">Testimonials</a></li>
    <li><a href="#">Contact Us</a></li>
</ul>

	6. Footer Widget 5:

<ul>
    <li><a href="#">Resource Library</a></li>
    <li><a href="#">Blog</a></li>
</ul>


	7. Socials Widget:

<h4>Follow us</h4>
<div class="social">
    <div class="social__item social__item--fb">
        <a href="#"><img src="/wp-content/themes/wp-odell/assets/img/icon/social_fb.svg" alt="" /> </a>
    </div>
    <div class="social__item social__item--in">
        <a href="#"><img src="/wp-content/themes/wp-odell/assets/img/icon/social_in.svg" alt="" /> </a>
    </div>
    <div class="social__item social__item--twi">
        <a href="#"><img src="/wp-content/themes/wp-odell/assets/img/icon/social_twi.svg" alt="" /> </a>
    </div>
    <div class="social__item social__item--gmail">
        <a href="#"><img src="/wp-content/themes/wp-odell/assets/img/icon/social_gmail.svg" alt="" /> </a>
    </div>
    <div class="social__item social__item--youtu">
        <a href="#"><img src="/wp-content/themes/wp-odell/assets/img/icon/social_youtu.svg" alt="" /> </a>
    </div>
</div>