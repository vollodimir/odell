</main>
      <footer class="footer">
        <div class="container">
          <div class="footer__widgets">
            <div class="widget footer__widgets--first">
              <div class="footer__logo">
                <?php 
                      if( get_custom_logo() ) {
                          the_custom_logo();
                        } else {
                          ?><a href="/"><img src="<?php bloginfo('template_url'); ?>/assets/img/logo.png" alt="Odell" /></a><?php
                        }
                  ?>
              </div>
              <div class="telephone">
                <a href="tel:<?php 
                        if(function_exists('get_field') && get_field('tel_number')){
                          $str = get_field('tel_number');
                        } else {
                          $str = '(469) 246-4500';
                        }
                          $pattern = '/[^0-9]/';
                          echo preg_replace($pattern, "", $str);
                        ?>"><?php odel_check_asf('tel_number', '(469) 246-4500') ?></a>
              </div>
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('address') ) : ?>
                <?php endif; ?>
            </div>

            <div class="widget">
              <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-1') ) : ?>
                <?php endif; ?> 
            </div>

            <div class="widget">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-2') ) : ?>
                <?php endif; ?> 
            </div>

            <div class="widget">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-3') ) : ?>
                <?php endif; ?> 
            </div>

            <div class="footer__column">
              <div class="widget">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-4') ) : ?>
                <?php endif; ?> 
              </div>

              <div class="widget">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-5') ) : ?>
                <?php endif; ?> 
              </div>
               <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('socials') ) : ?>
                <?php endif; ?> 
            </div>
          </div>
        </div>

        <div class="footer__copyright">
          <div class="container">
            <p>© 2022 <a href="#"><?php bloginfo('name'); ?></a>. All Right Reserved.</p>
          </div>
        </div>
      </footer>
    </div>

    <div class="go-top">
      <a href="#"> </a>
    </div>

    <?php wp_footer(); ?>
  </body>
</html>