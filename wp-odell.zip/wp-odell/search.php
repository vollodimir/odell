<?php get_header(); ?> 
        <section class="content">
          <div class="container">
                <section class="find-job">
                  <div class="container">
                    <div class="find-job__body">
                      <div class="find-job__left">
                      <form  role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                          <input
                            class="find-job__input-key"
                            type="text"
                            placeholder="Job Title, Skills or Keywords"
                            value="<?php echo get_search_query(); ?>" name="s" id="s"  
                          />
                          <div class="btn btn__secondary"><button type="submit" id="searchsubmit" value="<?php echo esc_attr_x( 'Search', 'submit button' ); ?>">Search</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
                </section>
              <?php if ( have_posts() ) : ?>
                <h1>Search results:</h1>
                  <?php
                    if ( category_description() ) : ?>
                    <p><?php echo category_description(); ?></p>
                    <?php endif; ?>
                  <div class="content__posts">
                    <?php
                      while ( have_posts() ) : the_post(); ?>
                      <a href="<?php the_permalink() ?>">
                        <div class="post post__form">
                        <h4><?php the_title(); ?></h4>
                          <?php the_content(); ?>
                        </div>
                      </a>
                    <?php endwhile; 
                      else: ?>
                          <div class="post" style='text-align:center; height:40vh; margin-top: 30%'>
                            <h2>Sorry, no posts matched your criteria.</h2>
                          </div>
                    <?php endif; ?>
                </div>
                <?php the_posts_pagination(); ?>
          </div>
        </section>
<?php get_footer(); ?>